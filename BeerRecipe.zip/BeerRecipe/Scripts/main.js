﻿
//$(document).ready(function() {
//    var ingredientModel = Backbone.Model.extend({
//        urlRoot: 'api/ingredients',
//        defaults: {
//            Id: 'Defualt Id',
//            Name: 'Default Name'
//        }

//    });

//    var Ingredients = Backbone.Collection.extend({
//        model: ingredientModel
//    });
//});



//var ingredient = new IngredientModel();
//var ingredientDetails = { Name: 'A new ingredient' };
//ingredient.save(ingredientDetails);