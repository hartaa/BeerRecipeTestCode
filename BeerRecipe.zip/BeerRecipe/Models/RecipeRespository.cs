﻿namespace BeerRecipe.Models
{
    public class RecipeRespository : Repository<Recipe>, IRecipeRepository<Recipe>
    {
        //Place holder interface until a method specific to the Recipe respository is needed.
    }
}