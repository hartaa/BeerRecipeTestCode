﻿using System.Linq;

namespace BeerRecipe.Models
{
    interface IRecipeRepository<T> : IRepository<T>
    {
        //Place holder interface until we need methods specific to RecipeRepository
    }
}
